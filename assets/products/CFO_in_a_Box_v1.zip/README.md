# CFO in a Box
The Financial OS for Sovereign Agents.
